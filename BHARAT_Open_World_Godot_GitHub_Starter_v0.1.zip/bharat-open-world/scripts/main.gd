extends Node3D
## BHARAT: Open World — playable web-first vertical slice.

const SAVE_PATH := "user://bharat_save.json"
const QUEST_LOCATIONS := {
    "chai": Vector3(-20, 0, -8.7),
    "post": Vector3(18, 0, -11),
    "doctor": Vector3(19, 0, 24.5),
    "elder": Vector3(-17, 0, 24.2)
}

var world: VillageWorld
var player: VillagePlayer
var quests := VillageQuests.new()
var ui_layer: CanvasLayer
var hud: Control
var title_screen: ColorRect
var mission_label: Label
var detail_label: Label
var info_label: Label
var hint_label: Label
var dialogue_panel: PanelContainer
var dialogue_label: Label
var map: VillageMinimap
var rain: CPUParticles3D
var ambient: AudioStreamPlayer
var effect: AudioStreamPlayer
var playing := false
var clock_hours := 9.0
var weather := "Clear"
var elapsed := 0.0
var update_timer := 0.0
var save_timer := 0.0
var dialogue_timer := 0.0
var status_message := ""

func _ready() -> void:
    _register_input()
    world = VillageWorld.new()
    world.name = "Sundarpur"
    add_child(world)
    player = VillagePlayer.new()
    player.position = Vector3(0, 2, 10)
    add_child(player)
    _setup_rain()
    _setup_audio()
    _setup_ui()
    _update_hud()
    title_screen.visible = true
    player.controls_enabled = false
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _register_input() -> void:
    var bindings := {
        "move_forward": [KEY_W, KEY_UP],
        "move_backward": [KEY_S, KEY_DOWN],
        "move_left": [KEY_A, KEY_LEFT],
        "move_right": [KEY_D, KEY_RIGHT],
        "interact": [KEY_E, KEY_ENTER],
        "sprint": [KEY_SHIFT],
        "jump": [KEY_SPACE],
        "menu": [KEY_ESCAPE],
        "camera_left": [KEY_Q],
        "camera_right": [KEY_R],
        "weather": [KEY_T]
    }
    for action in bindings:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
        for key in bindings[action]:
            var event := InputEventKey.new()
            event.physical_keycode = key
            InputMap.action_add_event(action, event)

func _setup_rain() -> void:
    rain = CPUParticles3D.new()
    rain.name = "MonsoonRain"
    rain.amount = 180
    rain.lifetime = 0.9
    rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    rain.emission_box_extents = Vector3(12, 0.5, 12)
    rain.direction = Vector3(0, -1, 0)
    rain.spread = 6.0
    rain.gravity = Vector3(0, -12, 0)
    rain.initial_velocity_min = 13.0
    rain.initial_velocity_max = 18.0
    var droplet := BoxMesh.new()
    droplet.size = Vector3(0.025, 0.35, 0.025)
    rain.mesh = droplet
    rain.color = Color(0.68, 0.81, 0.91, 0.55)
    rain.emitting = false
    rain.position = Vector3(0, 10, 0)
    player.add_child(rain)

func _setup_audio() -> void:
    ambient = AudioStreamPlayer.new()
    ambient.name = "VillageAmbience"
    ambient.volume_db = -21.0
    ambient.stream = load("res://assets/audio/village_ambience.wav")
    add_child(ambient)
    if ambient.stream is AudioStreamWAV:
        (ambient.stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
    ambient.play()
    effect = AudioStreamPlayer.new()
    effect.name = "InteractionChime"
    effect.volume_db = -13.0
    effect.stream = load("res://assets/audio/interaction.wav")
    add_child(effect)

func _style(bg: Color, border: Color = Color(0, 0, 0, 0), radius: int = 12) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = border
    style.set_border_width_all(1 if border.a > 0.0 else 0)
    style.set_corner_radius_all(radius)
    style.content_margin_left = 14
    style.content_margin_right = 14
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    return style

func _label(message: String, font_size: int = 18, color: Color = Color.WHITE) -> Label:
    var label := Label.new()
    label.text = message
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return label

func _button(message: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = message
    button.custom_minimum_size = Vector2(170, 46)
    button.add_theme_font_size_override("font_size", 17)
    button.add_theme_stylebox_override("normal", _style(Color("#b87b43")))
    button.add_theme_stylebox_override("hover", _style(Color("#d69b5b")))
    button.add_theme_stylebox_override("pressed", _style(Color("#865b36")))
    button.pressed.connect(callback)
    return button

func _setup_ui() -> void:
    ui_layer = CanvasLayer.new()
    add_child(ui_layer)
    hud = Control.new()
    hud.name = "HUD"
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui_layer.add_child(hud)

    var mission_panel := PanelContainer.new()
    mission_panel.position = Vector2(18, 18)
    mission_panel.custom_minimum_size = Vector2(370, 130)
    mission_panel.add_theme_stylebox_override("panel", _style(Color(0.07, 0.13, 0.13, 0.86), Color("#b99c68")))
    hud.add_child(mission_panel)
    var mission_column := VBoxContainer.new()
    mission_column.add_theme_constant_override("separation", 5)
    mission_panel.add_child(mission_column)
    mission_column.add_child(_label("SUNDARPUR · STORY QUEST", 13, Color("#e4c88f")))
    mission_label = _label("A Warm Welcome", 22)
    mission_column.add_child(mission_label)
    detail_label = _label("Find Ravi at Chai Corner.", 15, Color("#e4e2d6"))
    mission_column.add_child(detail_label)

    map = VillageMinimap.new()
    map.name = "Minimap"
    map.player = player
    map.world = world
    map.custom_minimum_size = Vector2(195, 195)
    map.size = Vector2(195, 195)
    map.anchor_left = 1.0
    map.anchor_right = 1.0
    map.offset_left = -213
    map.offset_right = -18
    map.offset_top = 18
    map.offset_bottom = 213
    hud.add_child(map)

    info_label = _label("09:00 · Clear · Sundarpur", 15, Color("#fff4d5"))
    info_label.anchor_left = 1.0
    info_label.anchor_right = 1.0
    info_label.offset_left = -310
    info_label.offset_right = -18
    info_label.offset_top = 224
    info_label.offset_bottom = 254
    info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    hud.add_child(info_label)

    var pause_button := _button("☰  MENU", _show_menu)
    pause_button.custom_minimum_size = Vector2(125, 40)
    pause_button.anchor_left = 1.0
    pause_button.anchor_right = 1.0
    pause_button.offset_left = -145
    pause_button.offset_right = -18
    pause_button.offset_top = 263
    pause_button.offset_bottom = 309
    hud.add_child(pause_button)

    hint_label = _label("", 19, Color("#fff1cc"))
    hint_label.anchor_top = 1.0
    hint_label.anchor_bottom = 1.0
    hint_label.anchor_left = 0.2
    hint_label.anchor_right = 0.8
    hint_label.offset_top = -128
    hint_label.offset_bottom = -86
    hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud.add_child(hint_label)

    dialogue_panel = PanelContainer.new()
    dialogue_panel.add_theme_stylebox_override("panel", _style(Color(0.07, 0.14, 0.15, 0.95), Color("#e2b876")))
    dialogue_panel.anchor_left = 0.2
    dialogue_panel.anchor_right = 0.8
    dialogue_panel.anchor_top = 1.0
    dialogue_panel.anchor_bottom = 1.0
    dialogue_panel.offset_top = -212
    dialogue_panel.offset_bottom = -142
    dialogue_label = _label("", 18)
    dialogue_panel.add_child(dialogue_label)
    dialogue_panel.visible = false
    hud.add_child(dialogue_panel)

    var controls_hint := _label("WASD move  ·  Shift run  ·  Space jump  ·  E talk  ·  Right-click look  ·  T rain", 13, Color("#f6e9d4"))
    controls_hint.anchor_top = 1.0
    controls_hint.anchor_bottom = 1.0
    controls_hint.offset_left = 18
    controls_hint.offset_right = 760
    controls_hint.offset_top = -30
    controls_hint.offset_bottom = -8
    hud.add_child(controls_hint)
    _setup_touch_controls()
    _setup_title_screen()

func _touch_button(text_value: String, action: String, where: Vector2) -> void:
    var button := Button.new()
    button.text = text_value
    button.position = where
    button.custom_minimum_size = Vector2(54, 54)
    button.add_theme_font_size_override("font_size", 24)
    button.add_theme_stylebox_override("normal", _style(Color(0.09, 0.19, 0.20, 0.7), Color("#d6c194")))
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    button.visibility_changed.connect(func():
        if not button.visible:
            Input.action_release(action)
    )
    hud.add_child(button)

func _setup_touch_controls() -> void:
    if not DisplayServer.is_touchscreen_available() and not OS.has_feature("mobile"):
        return
    var touch := Control.new()
    touch.name = "TouchControls"
    touch.anchor_top = 1.0
    touch.anchor_bottom = 1.0
    touch.offset_top = -245
    touch.offset_bottom = -50
    touch.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(touch)
    # Buttons use viewport-relative anchors to remain accessible in landscape.
    for data in [
        ["▲", "move_forward", Vector2(88, -190)],
        ["▼", "move_backward", Vector2(88, -72)],
        ["◀", "move_left", Vector2(26, -130)],
        ["▶", "move_right", Vector2(150, -130)],
        ["↶", "camera_left", Vector2(-245, -130)],
        ["↷", "camera_right", Vector2(-180, -130)],
        ["E", "interact", Vector2(-115, -130)],
        ["↥", "jump", Vector2(-115, -68)],
        ["RUN", "sprint", Vector2(-115, -190)]
    ]:
        var action_button := Button.new()
        action_button.text = data[0]
        action_button.custom_minimum_size = Vector2(56, 56)
        action_button.add_theme_font_size_override("font_size", 18)
        action_button.add_theme_stylebox_override("normal", _style(Color(0.07, 0.16, 0.18, 0.73), Color("#e1c58e")))
        action_button.anchor_top = 1.0
        action_button.anchor_bottom = 1.0
        var button_offset: Vector2 = data[2]
        if button_offset.x < 0:
            action_button.anchor_left = 1.0
            action_button.anchor_right = 1.0
        action_button.position = data[2]
        var action_name: String = data[1]
        action_button.button_down.connect(func(): Input.action_press(action_name))
        action_button.button_up.connect(func(): Input.action_release(action_name))
        hud.add_child(action_button)

func _setup_title_screen() -> void:
    title_screen = ColorRect.new()
    title_screen.name = "MainMenu"
    title_screen.color = Color(0.035, 0.09, 0.10, 0.94)
    title_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_layer.add_child(title_screen)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    title_screen.add_child(center)
    var content := VBoxContainer.new()
    content.custom_minimum_size = Vector2(420, 0)
    content.add_theme_constant_override("separation", 15)
    center.add_child(content)
    var eyebrow := _label("AN ORIGINAL INDIAN OPEN-WORLD ADVENTURE", 14, Color("#e1bf86"))
    eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    content.add_child(eyebrow)
    var heading := _label("B H A R A T", 58, Color("#fff1d0"))
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    content.add_child(heading)
    var subtitle := _label("S U N D A R P U R  ·  A  L I V I N G  V I L L A G E", 16, Color("#e3cfa8"))
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    content.add_child(subtitle)
    content.add_child(HSeparator.new())
    var description := _label("Explore a sunlit village. Meet its people. Deliver a precious parcel. Discover places, experience the monsoon, and make Sundarpur your own.", 18, Color("#f1e8d8"))
    description.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    content.add_child(description)
    content.add_child(_button("NEW JOURNEY", _start_new))
    var continue_button := _button("CONTINUE SAVED GAME", _continue_game)
    continue_button.disabled = not FileAccess.file_exists(SAVE_PATH)
    content.add_child(continue_button)
    content.add_child(_button("RETURN TO GAME", _resume_game))
    var note := _label("WASD · MOVE    |    E · INTERACT    |    T · MONSOON    |    ESC · MENU", 13, Color("#d7c29d"))
    note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    content.add_child(note)
    var build := _label("PRE-ALPHA 0.1  ·  FREE & OPEN SOURCE", 12, Color("#a7b4ab"))
    build.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    content.add_child(build)

func _start_new() -> void:
    quests = VillageQuests.new()
    clock_hours = 9.0
    weather = "Clear"
    rain.emitting = false
    player.global_position = Vector3(0, 2, 10)
    _resume_game()
    _speak("Welcome to Sundarpur! Your first stop is Chai Corner.")
    _save_game()

func _continue_game() -> void:
    if _load_game():
        _resume_game()
        _speak("Welcome back to Sundarpur!")
    else:
        _start_new()

func _resume_game() -> void:
    playing = true
    title_screen.visible = false
    player.controls_enabled = true
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _update_hud()

func _show_menu() -> void:
    playing = false
    player.controls_enabled = false
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    title_screen.visible = true
    _save_game()

func _interact() -> void:
    var nearby := world.nearest_person(player.global_position)
    if nearby.is_empty():
        _speak("No one is close enough to talk to. Walk toward a villager.")
        return
    var previous := quests.step
    var response := quests.interact(str(nearby["id"]))
    if effect.stream != null:
        effect.play()
    _speak(response)
    if quests.step != previous:
        _save_game()
    _update_hud()

func _toggle_weather() -> void:
    weather = "Monsoon" if weather == "Clear" else "Clear"
    rain.emitting = weather == "Monsoon"
    _speak("Monsoon clouds roll in." if rain.emitting else "The skies have cleared.")
    _update_hud()

func _speak(message: String) -> void:
    dialogue_label.text = message
    dialogue_panel.visible = true
    dialogue_timer = 5.8

func _process(delta: float) -> void:
    if not playing:
        return
    if Input.is_action_just_pressed("interact"):
        _interact()
    if Input.is_action_just_pressed("weather"):
        _toggle_weather()
    if Input.is_action_just_pressed("menu"):
        _show_menu()
        return
    elapsed += delta
    clock_hours = fmod(clock_hours + delta * 0.014, 24.0)
    world.animate_people(elapsed)
    update_timer += delta
    save_timer += delta
    if dialogue_timer > 0.0:
        dialogue_timer -= delta
        if dialogue_timer <= 0.0:
            dialogue_panel.visible = false
    if update_timer >= 0.3:
        update_timer = 0.0
        world.set_clock(clock_hours)
        _check_discoveries()
        _update_hud()
    if save_timer >= 30.0:
        save_timer = 0.0
        _save_game()

func _check_discoveries() -> void:
    for point in world.points_of_interest:
        if player.global_position.distance_to(point["position"]) < 8.0:
            if quests.discover(str(point["id"])):
                _speak("Landmark discovered: %s  ·  %d/4" % [point["name"], quests.completed_landmarks.size()])
                _save_game()

func _update_hud() -> void:
    if mission_label == null:
        return
    var objective := quests.objective()
    mission_label.text = str(objective["title"])
    detail_label.text = str(objective["description"])
    info_label.text = "%02d:%02d  ·  %s  ·  %d/4 places" % [int(clock_hours), int(fmod(clock_hours * 60.0, 60.0)), weather, quests.completed_landmarks.size()]
    var nearby := world.nearest_person(player.global_position)
    hint_label.text = "[ E ]  Talk to %s" % nearby["name"] if not nearby.is_empty() else "Explore Sundarpur · Follow the gold map marker"
    var target_id := str(objective["target"])
    map.show_target = QUEST_LOCATIONS.has(target_id)
    if map.show_target:
        map.target = QUEST_LOCATIONS[target_id]

func _save_game() -> void:
    if not playing and not FileAccess.file_exists(SAVE_PATH):
        return
    var data := quests.serialize()
    data["save_version"] = 1
    data["clock_hours"] = clock_hours
    data["weather"] = weather
    data["position"] = [player.global_position.x, player.global_position.y, player.global_position.z]
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Save unavailable: error %d" % FileAccess.get_open_error())
        return
    file.store_string(JSON.stringify(data))
    file.close()

func _load_game() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return false
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return false
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if not parsed is Dictionary or int(parsed.get("save_version", 0)) != 1:
        return false
    quests.load_progress(parsed)
    clock_hours = clampf(float(parsed.get("clock_hours", 9.0)), 0.0, 23.99)
    weather = "Monsoon" if parsed.get("weather", "Clear") == "Monsoon" else "Clear"
    rain.emitting = weather == "Monsoon"
    var position_data = parsed.get("position", [])
    if position_data is Array and position_data.size() == 3:
        var x := clampf(float(position_data[0]), -65.0, 65.0)
        var y := clampf(float(position_data[1]), 1.0, 12.0)
        var z := clampf(float(position_data[2]), -65.0, 65.0)
        player.global_position = Vector3(x, y, z)
    return true
