extends RefCounted
class_name VillageQuests
## Pure mission progression; can be tested without loading a 3D scene.

const STEPS := [
    {"target": "chai", "title": "A Warm Welcome", "description": "Find Ravi at Chai Corner and introduce yourself."},
    {"target": "post", "title": "Special Delivery", "description": "Visit Meera at the Post Office to collect a parcel."},
    {"target": "doctor", "title": "Helping Hands", "description": "Deliver the medicine parcel to Dr. Asha at the Health Clinic."},
    {"target": "elder", "title": "Village Stories", "description": "Speak with Dadaji near the elder's home."}
]

var step := 0
var completed_landmarks: Array[String] = []

func objective() -> Dictionary:
    if step >= STEPS.size():
        return {"target": "", "title": "Village Hero", "description": "All story quests complete! Explore the landmarks."}
    return STEPS[step]

func interact(person_id: String) -> String:
    if step >= STEPS.size():
        return "Thank you for helping our village. Enjoy exploring!"
    if person_id != STEPS[step]["target"]:
        return _ambient_dialogue(person_id)
    step += 1
    match person_id:
        "chai": return "Ravi: Welcome to Sundarpur! Meera at the post office needs help."
        "post": return "Meera: Please take this medicine parcel to Dr. Asha at the clinic."
        "doctor": return "Dr. Asha: Perfect timing! Dadaji wanted to thank you personally."
        "elder": return "Dadaji: Sundarpur remembers kindness. You are one of us now!"
    return "A new chapter begins."

func _ambient_dialogue(person_id: String) -> String:
    match person_id:
        "chai": return "Ravi: The best stories begin with a cup of chai."
        "post": return "Meera: Letters connect the whole village."
        "doctor": return "Dr. Asha: Stay hydrated in this heat!"
        "elder": return "Dadaji: Every tree here has seen a hundred monsoons."
        "walker1": return "Aarav: The pond looks beautiful at sunset."
        "walker2": return "Kavya: Have you visited Shanti Mandir?"
    return "Namaste! Welcome to Sundarpur."

func discover(id: String) -> bool:
    if id in completed_landmarks:
        return false
    completed_landmarks.append(id)
    return true

func load_progress(data: Dictionary) -> void:
    step = clampi(int(data.get("quest_step", 0)), 0, STEPS.size())
    completed_landmarks.clear()
    var values = data.get("discovered", [])
    if values is Array:
        for item in values:
            if item is String and not item in completed_landmarks:
                completed_landmarks.append(item)

func serialize() -> Dictionary:
    return {"quest_step": step, "discovered": completed_landmarks.duplicate()}
