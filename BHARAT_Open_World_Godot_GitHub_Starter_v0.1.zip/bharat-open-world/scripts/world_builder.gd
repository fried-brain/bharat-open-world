extends Node3D
class_name VillageWorld
## Deterministic, asset-free village geometry. All landmarks are hand placed.

const EXTENT := 68.0
var points_of_interest: Array[Dictionary] = []
var people: Array[Dictionary] = []
var sun: DirectionalLight3D
var sky_environment: WorldEnvironment
var street_lights: Array[OmniLight3D] = []
var palette := {
    "sand": Color("#c7ad7a"), "soil": Color("#876d49"),
    "road": Color("#bda27c"), "wall": Color("#dfc29b"),
    "brick": Color("#b66b52"), "roof": Color("#96594b"),
    "leaf": Color("#54804c"), "leaf_dark": Color("#355d3b"),
    "water": Color("#5a9b9f"), "wood": Color("#6e4933")
}

func _ready() -> void:
    _setup_lighting()
    _terrain()
    _roads()
    _buildings()
    _nature()
    _people()
    set_clock(9.0)

func material(color: Color, rough: float = 0.95) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    return m

func box_shape(parent: Node3D, label: String, at: Vector3, dimensions: Vector3, color: Color, solid: bool = false) -> MeshInstance3D:
    var mesh_node := MeshInstance3D.new()
    mesh_node.name = label
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    mesh_node.mesh = mesh
    mesh_node.material_override = material(color)
    mesh_node.position = at
    parent.add_child(mesh_node)
    if solid:
        var body := StaticBody3D.new()
        var collision := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = dimensions
        collision.shape = shape
        body.add_child(collision)
        mesh_node.add_child(body)
    return mesh_node

func cylinder(parent: Node3D, label: String, at: Vector3, radius: float, height: float, color: Color, top_radius: float = -1.0) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = label
    var mesh := CylinderMesh.new()
    mesh.bottom_radius = radius
    mesh.top_radius = radius if top_radius < 0.0 else top_radius
    mesh.height = height
    mesh.radial_segments = 10
    node.mesh = mesh
    node.material_override = material(color)
    node.position = at
    parent.add_child(node)
    return node

func sphere(parent: Node3D, label: String, at: Vector3, radius: float, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = label
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 12
    mesh.rings = 6
    node.mesh = mesh
    node.material_override = material(color)
    node.position = at
    parent.add_child(node)
    return node

func sign_text(parent: Node3D, message: String, at: Vector3, color: Color = Color("#f9e9ce"), scale_factor: float = 1.0) -> void:
    var label := Label3D.new()
    label.text = message
    label.font_size = 42
    label.pixel_size = 0.008 * scale_factor
    label.modulate = color
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.no_depth_test = true
    label.position = at
    parent.add_child(label)

func _setup_lighting() -> void:
    sky_environment = WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#9cc5df")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#c9d8dd")
    env.ambient_light_energy = 0.65
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    sky_environment.environment = env
    add_child(sky_environment)
    sun = DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation_degrees = Vector3(-50, -35, 0)
    sun.light_color = Color("#ffe3b4")
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 85.0
    add_child(sun)

func _terrain() -> void:
    box_shape(self, "Earth", Vector3(0, -0.4, 0), Vector3(EXTENT * 2, 0.8, EXTENT * 2), palette.sand, true)
    # Colored surrounding agricultural patches.
    for ix in range(-3, 4):
        for iz in range(-3, 4):
            if abs(ix) < 2 and abs(iz) < 2:
                continue
            var px := float(ix) * 17.0 + 3.0
            var pz := float(iz) * 17.0 + 3.0
            if abs(px) > 60.0 or abs(pz) > 60.0:
                continue
            box_shape(self, "Farmland", Vector3(px, 0.02, pz), Vector3(13, 0.05, 13), Color("#8b9c5b") if (ix + iz) % 2 == 0 else Color("#a58e56"))
            for row in range(6):
                box_shape(self, "Crop row", Vector3(px - 5.4 + row * 2.1, 0.14, pz), Vector3(0.45, 0.24, 11.0), Color("#55753c"))

func _roads() -> void:
    box_shape(self, "Village north-south road", Vector3(0, 0.055, 0), Vector3(9, 0.12, 115), palette.road)
    box_shape(self, "Village east-west road", Vector3(0, 0.065, 0), Vector3(115, 0.12, 9), palette.road)
    for x in [-4.5, 4.5]:
        box_shape(self, "Road border", Vector3(x, 0.14, 0), Vector3(0.18, 0.13, 115), Color("#dfcba4"))
    for z in [-4.5, 4.5]:
        box_shape(self, "Road border", Vector3(0, 0.14, z), Vector3(115, 0.13, 0.18), Color("#dfcba4"))
    # Small street markings create an easy-to-follow central junction.
    for x in range(-48, 49, 12):
        if abs(x) > 9:
            box_shape(self, "Road marking", Vector3(x, 0.135, 0), Vector3(3.0, 0.02, 0.12), Color("#e3d5ad"))

func _house(label: String, at: Vector3, wall: Color, width: float = 7.0) -> void:
    var group := Node3D.new()
    group.name = label
    group.position = at
    add_child(group)
    box_shape(group, "Walls", Vector3(0, 1.75, 0), Vector3(width, 3.5, 6.3), wall, true)
    box_shape(group, "Roof", Vector3(0, 3.68, 0), Vector3(width + 0.9, 0.42, 7.2), palette.roof)
    box_shape(group, "Door", Vector3(0, 1.05, 3.19), Vector3(1.4, 2.1, 0.06), palette.wood)
    box_shape(group, "Window L", Vector3(-width * 0.32, 2.1, 3.19), Vector3(1.1, 0.9, 0.07), Color("#5c8e9c"))
    box_shape(group, "Window R", Vector3(width * 0.32, 2.1, 3.19), Vector3(1.1, 0.9, 0.07), Color("#5c8e9c"))
    sign_text(group, label, Vector3(0, 4.75, 0), Color("#fff3d3"), 0.8)

func _buildings() -> void:
    _house("Chai Corner", Vector3(-20, 0, -19), Color("#d3a274"), 8)
    _house("Post Office", Vector3(18, 0, -19), Color("#e3c49e"), 8)
    _house("Health Clinic", Vector3(19, 0, 18), Color("#d8d9b8"), 9)
    _house("Elder's Home", Vector3(-17, 0, 18), Color("#c79b77"), 8)
    _house("Pottery House", Vector3(-40, 0, -14), Color("#d8b78d"))
    _house("School", Vector3(40, 0, 17), Color("#d4caa2"), 10)
    _house("Weaver's Home", Vector3(-39, 0, 40), Color("#d7a98e"))
    _house("Bakery", Vector3(39, 0, 41), Color("#b9bb95"))
    _house("Village Hall", Vector3(-17, 0, 43), Color("#e2c18e"), 10)
    # Chai counter, benches and colorful market awnings.
    box_shape(self, "Chai counter", Vector3(-20, 0.9, -11.6), Vector3(5, 1.5, 1.1), palette.wood, true)
    box_shape(self, "Chai awning", Vector3(-20, 3.3, -11.4), Vector3(7.0, 0.15, 3.0), Color("#bd6c42"))
    for x in [-23.0, -17.0]:
        cylinder(self, "Market pole", Vector3(x, 1.65, -9.95), 0.1, 3.3, palette.wood)
    for x in [-27.0, -12.0, 12.0, 28.0]:
        box_shape(self, "Roadside bench", Vector3(x, 0.5, 7.8), Vector3(2.4, 0.3, 0.7), palette.wood)
    # Temple and courtyard.
    box_shape(self, "Temple plinth", Vector3(-43, 0.5, 26), Vector3(11, 1, 11), Color("#d2b8a0"), true)
    box_shape(self, "Temple shrine", Vector3(-43, 3.1, 26), Vector3(6.0, 4.4, 6.0), Color("#dfb88d"))
    cylinder(self, "Temple spire", Vector3(-43, 7.7, 26), 3.3, 5.0, Color("#b97150"), 0.0)
    sign_text(self, "SHANTI MANDIR", Vector3(-43, 10.8, 26))
    # Well, fountain and village square.
    cylinder(self, "Stone well", Vector3(10, 0.65, 10), 1.65, 1.3, Color("#ad9981"))
    cylinder(self, "Well water", Vector3(10, 1.34, 10), 1.3, 0.05, palette.water)
    # Street lamps.
    for p in [Vector3(-8, 0, -8), Vector3(8, 0, -8), Vector3(8, 0, 8), Vector3(-8, 0, 8)]:
        cylinder(self, "Lamp post", p + Vector3(0, 2.4, 0), 0.12, 4.8, Color("#4f5148"))
        sphere(self, "Lantern", p + Vector3(0, 4.9, 0), 0.38, Color("#ffe2a2"))
        var lamp := OmniLight3D.new()
        lamp.position = p + Vector3(0, 4.8, 0)
        lamp.light_color = Color("#ffd49b")
        lamp.light_energy = 0.0
        lamp.omni_range = 12.0
        add_child(lamp)
        street_lights.append(lamp)

func _tree(at: Vector3, big: bool = false) -> void:
    var h := 5.2 if big else 3.4
    cylinder(self, "Neem tree trunk", at + Vector3(0, h * 0.5, 0), 0.43 if big else 0.25, h, palette.wood)
    for offset in [Vector3(-1.1, 0, 0), Vector3(1.0, 0.5, 0.4), Vector3(0, 1.0, -0.7)]:
        sphere(self, "Tree canopy", at + Vector3(0, h + 1.0, 0) + offset * (1.5 if big else 1.0), 2.5 if big else 1.6, palette.leaf if offset.x < 0 else palette.leaf_dark)

func _nature() -> void:
    var trees := [Vector3(-11, 0, -37), Vector3(10, 0, -36), Vector3(-31, 0, 9), Vector3(30, 0, 8), Vector3(-29, 0, 34), Vector3(28, 0, 31), Vector3(51, 0, -11), Vector3(-52, 0, -42), Vector3(50, 0, 53), Vector3(-53, 0, 54)]
    for i in range(trees.size()):
        _tree(trees[i], i % 3 == 0)
    # Pond: a shallow colored surface surrounded by rocks and reeds.
    cylinder(self, "Pond shore", Vector3(37, 0.055, -38), 10.0, 0.1, Color("#827b55"))
    cylinder(self, "Village pond", Vector3(37, 0.13, -38), 8.6, 0.07, palette.water)
    sign_text(self, "LOTUS POND", Vector3(37, 2.8, -38))
    for i in range(12):
        var a := TAU * float(i) / 12.0
        sphere(self, "Pond stone", Vector3(37 + cos(a) * 9.2, 0.25, -38 + sin(a) * 9.2), 0.5, Color("#8e8c78"))
    # A few props around the village square.
    for i in range(8):
        var angle := TAU * float(i) / 8.0
        var x := cos(angle) * 13.0
        var z := sin(angle) * 13.0
        if abs(x) < 5.0 or abs(z) < 5.0:
            continue
        cylinder(self, "Clay pot", Vector3(x, 0.45, z), 0.42, 0.9, Color("#a96242"), 0.3)

func _make_person(id: String, display: String, at: Vector3, clothing: Color, wander: bool = false) -> void:
    var root := Node3D.new()
    root.name = id
    root.position = at
    add_child(root)
    cylinder(root, "Kurta", Vector3(0, 1.25, 0), 0.38, 1.15, clothing, 0.31)
    sphere(root, "Head", Vector3(0, 2.17, 0), 0.32, Color("#b77e58"))
    sphere(root, "Hair", Vector3(0, 2.43, -0.02), 0.27, Color("#33291f"))
    for x in [-0.22, 0.22]:
        cylinder(root, "Leg", Vector3(x, 0.43, 0), 0.13, 0.85, Color("#d5c4a1"))
    sign_text(root, display, Vector3(0, 3.1, 0), Color("#fff8df"), 0.72)
    people.append({"id": id, "name": display, "node": root, "home": at, "wander": wander, "phase": float(people.size()) * 1.7})

func _people() -> void:
    _make_person("chai", "Ravi · Chaiwala", Vector3(-20, 0, -8.7), Color("#5d9a92"))
    _make_person("post", "Meera · Postmaster", Vector3(18, 0, -11.0), Color("#aa685a"))
    _make_person("doctor", "Dr. Asha", Vector3(19, 0, 24.5), Color("#e4e4d5"))
    _make_person("elder", "Dadaji", Vector3(-17, 0, 24.2), Color("#b8a0cf"))
    _make_person("walker1", "Aarav", Vector3(-7, 0, 13), Color("#7498bf"), true)
    _make_person("walker2", "Kavya", Vector3(8, 0, -15), Color("#c9858e"), true)
    points_of_interest = [
        {"id": "temple", "name": "Shanti Mandir", "position": Vector3(-43, 0, 26)},
        {"id": "pond", "name": "Lotus Pond", "position": Vector3(37, 0, -38)},
        {"id": "school", "name": "Village School", "position": Vector3(40, 0, 17)},
        {"id": "hall", "name": "Village Hall", "position": Vector3(-17, 0, 43)}
    ]

func nearest_person(at: Vector3, max_distance: float = 3.7) -> Dictionary:
    var nearest: Dictionary = {}
    var best := max_distance
    for person in people:
        var dist := at.distance_to((person["node"] as Node3D).global_position)
        if dist < best:
            best = dist
            nearest = person
    return nearest

func set_clock(hour: float) -> void:
    var angle := (hour - 12.0) * 15.0
    sun.rotation_degrees = Vector3(-maxf(5.0, 80.0 - absf(angle) * 0.35), -40.0 + angle * 0.5, 0)
    var daytime := hour >= 6.0 and hour < 19.0
    sun.light_energy = 1.25 if daytime else 0.12
    sun.light_color = Color("#ffe1ad") if daytime else Color("#94a5cc")
    sky_environment.environment.background_color = Color("#9cc5df") if daytime else Color("#182944")
    sky_environment.environment.ambient_light_energy = 0.7 if daytime else 0.25
    for lamp in street_lights:
        lamp.light_energy = 0.0 if daytime else 1.5

func animate_people(seconds: float) -> void:
    for person in people:
        if person["wander"]:
            var node := person["node"] as Node3D
            var home: Vector3 = person["home"]
            var phase := seconds * 0.22 + float(person["phase"])
            node.position = home + Vector3(sin(phase) * 3.2, 0, cos(phase * 0.8) * 2.0)
