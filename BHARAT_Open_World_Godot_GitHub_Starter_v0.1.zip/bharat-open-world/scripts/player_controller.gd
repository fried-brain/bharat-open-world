extends CharacterBody3D
class_name VillagePlayer
## Third-person keyboard/mouse and on-screen action controller.

const WALK_SPEED := 5.6
const RUN_SPEED := 9.1
const JUMP_VELOCITY := 7.8
const MOUSE_SENSITIVITY := 0.003
var controls_enabled := false
var camera_yaw := 0.0
var camera_pitch := -0.19
var body_visual: Node3D
var pivot: Node3D
var camera: Camera3D
var walk_clock := 0.0

func _ready() -> void:
    name = "Explorer"
    collision_layer = 2
    collision_mask = 1
    var collider := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.9
    collider.shape = capsule
    add_child(collider)
    body_visual = Node3D.new()
    body_visual.name = "CharacterArt"
    add_child(body_visual)
    _build_character()
    pivot = Node3D.new()
    pivot.position = Vector3(0, 1.25, 0)
    pivot.name = "CameraRig"
    add_child(pivot)
    camera = Camera3D.new()
    camera.name = "ThirdPersonCamera"
    camera.current = true
    camera.fov = 72.0
    camera.near = 0.1
    pivot.add_child(camera)
    _update_camera()

func _mesh_box(label: String, at: Vector3, dimensions: Vector3, tint: Color) -> void:
    var item := MeshInstance3D.new()
    item.name = label
    var box := BoxMesh.new()
    box.size = dimensions
    item.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    item.material_override = mat
    item.position = at
    body_visual.add_child(item)

func _build_character() -> void:
    _mesh_box("Blue kurta", Vector3(0, 0.0, 0), Vector3(0.72, 0.96, 0.4), Color("#326a86"))
    _mesh_box("Head", Vector3(0, 0.75, 0), Vector3(0.47, 0.49, 0.45), Color("#b97c56"))
    _mesh_box("Hair", Vector3(0, 1.01, -0.025), Vector3(0.49, 0.15, 0.48), Color("#27221f"))
    _mesh_box("Left leg", Vector3(-0.21, -0.69, 0), Vector3(0.26, 0.55, 0.29), Color("#e1d1b5"))
    _mesh_box("Right leg", Vector3(0.21, -0.69, 0), Vector3(0.26, 0.55, 0.29), Color("#e1d1b5"))
    _mesh_box("Left arm", Vector3(-0.47, 0.02, 0), Vector3(0.21, 0.76, 0.25), Color("#326a86"))
    _mesh_box("Right arm", Vector3(0.47, 0.02, 0), Vector3(0.21, 0.76, 0.25), Color("#326a86"))

func _unhandled_input(event: InputEvent) -> void:
    if not controls_enabled:
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        camera_yaw -= event.relative.x * MOUSE_SENSITIVITY
        camera_pitch = clampf(camera_pitch - event.relative.y * MOUSE_SENSITIVITY, -0.7, 0.2)
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= 22.0 * delta
    if not controls_enabled:
        velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
        move_and_slide()
        return
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_VELOCITY
    var turn := Input.get_axis("camera_left", "camera_right")
    camera_yaw -= turn * delta * 1.8
    var input := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
    var forward := Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
    var right := Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
    var direction := (right * input.x - forward * input.y).normalized()
    var speed := RUN_SPEED if Input.is_action_pressed("sprint") else WALK_SPEED
    velocity.x = move_toward(velocity.x, direction.x * speed, 18.0 * delta)
    velocity.z = move_toward(velocity.z, direction.z * speed, 18.0 * delta)
    if direction.length_squared() > 0.01:
        body_visual.rotation.y = lerp_angle(body_visual.rotation.y, atan2(-direction.x, -direction.z), 11.0 * delta)
        walk_clock += delta * speed
        body_visual.position.y = sin(walk_clock * 2.2) * 0.045
    else:
        body_visual.position.y = lerpf(body_visual.position.y, 0.0, 9.0 * delta)
    move_and_slide()
    # Keep the character inside the authored playable area.
    global_position.x = clampf(global_position.x, -65.0, 65.0)
    global_position.z = clampf(global_position.z, -65.0, 65.0)

func _process(_delta: float) -> void:
    _update_camera()

func _update_camera() -> void:
    if not is_instance_valid(camera):
        return
    var horizontal := 7.5 * cos(camera_pitch)
    camera.position = Vector3(sin(camera_yaw) * horizontal, 2.6 - sin(camera_pitch) * 7.5, cos(camera_yaw) * horizontal)
    camera.look_at(pivot.global_position + Vector3(0, 0.45, 0), Vector3.UP)
