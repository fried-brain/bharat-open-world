extends Control
class_name VillageMinimap
## Compact top-down map with player, four landmarks and current objective.

var player: Node3D
var world: VillageWorld
var target: Vector3
var show_target := false
const RADIUS := 68.0

func _process(_delta: float) -> void:
    queue_redraw()

func _project(position_3d: Vector3) -> Vector2:
    var usable := size - Vector2(20, 20)
    return Vector2(10, 10) + Vector2((position_3d.x + RADIUS) / (RADIUS * 2.0), (position_3d.z + RADIUS) / (RADIUS * 2.0)) * usable

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.06, 0.13, 0.13, 0.84), true)
    draw_rect(Rect2(Vector2(8, 8), size - Vector2(16, 16)), Color("#617750"), true)
    var a := _project(Vector3(-4.5, 0, -57))
    var b := _project(Vector3(4.5, 0, 57))
    draw_rect(Rect2(a, b - a), Color("#bba77c"), true)
    a = _project(Vector3(-57, 0, -4.5))
    b = _project(Vector3(57, 0, 4.5))
    draw_rect(Rect2(a, b - a), Color("#bba77c"), true)
    if is_instance_valid(world):
        for landmark in world.points_of_interest:
            draw_circle(_project(landmark["position"]), 4.0, Color("#f2d08b"))
    if show_target:
        var target_at := _project(target)
        draw_circle(target_at, 7.0, Color("#f2c55d"))
        draw_arc(target_at, 9.0, 0, TAU, 24, Color.WHITE, 1.5)
    if is_instance_valid(player):
        var center := _project(player.global_position)
        draw_circle(center, 5.8, Color("#4fd5e0"))
        draw_arc(center, 7.8, 0, TAU, 24, Color.WHITE, 1.2)
    draw_rect(Rect2(Vector2.ZERO, size), Color("#d2c39a"), false, 2.0)
