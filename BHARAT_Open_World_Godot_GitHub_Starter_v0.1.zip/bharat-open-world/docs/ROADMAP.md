# Product Roadmap — BHARAT: Open World

## Vision

A culturally grounded, original Indian village life adventure that begins with a small walkable community and grows into a living region. The tone is welcoming, exploratory and story-driven; characters and locations are fictional.

## Release 0.1 — Playable village vertical slice (initial repository)

**Deliverables:** Procedural 3D village, third-person player, six NPCs, four sequential missions, four landmarks, minimap, weather toggle, day/night lighting, local save/continue, original synthesized sound, basic touchscreen input, CI and GitHub Pages export workflow.

**Acceptance:** Project imports in Godot 4.4.1, smoke test passes, Web export succeeds, quest chain completes, progress survives reload, desktop controls work, mobile touch controls are tested on real devices. Engine/browser verification is pending until CI runs.

## Release 0.2 — Village systems (suggested 4–6 weeks for a small team)

- Replace primitive placeholder characters/buildings with licensed original or properly attributed production assets.
- Add interaction dialogue UI with branching choices and accessibility settings.
- Add shop inventory, simple currency and transactions, an in-game journal.
- Add NPC daily routines and navigation with obstacle avoidance.
- Add map labels, accessibility contrast and remappable controls.
- Profile desktop and Android browsers with performance metrics.

**Exit criteria:** 3 complete repeatable activities, no critical gameplay bugs, stable 30 FPS on selected mobile reference hardware.

## Release 0.3 — Vehicle sandbox (suggested 6–8 weeks)

- Motorbike controller with acceleration, braking, leaning, collision and third-person follow camera.
- Road network with intersections and simple civilian traffic agents.
- Parking, mounting/dismounting, vehicle persistence and repair loop.

**Exit criteria:** Two routes and three vehicle challenges, no physics instability during a 30-minute test session.

## Release 0.4 — Expanded region (suggested 8–12 weeks)

- Authored terrain chunks, streaming and LOD.
- Three connected settlements, agricultural areas and explorable interiors.
- Ambient animals, weather forecast patterns, crop and market loops.

**Exit criteria:** Traversal across connected areas without a blocking load; memory budget measured on supported browsers.

## Release 0.5 — Narrative and simulation (suggested 8–12 weeks)

- Faction reputation, occupations, festivals and story branches.
- NPC schedule system, multi-step missions, inventory and economy balance.
- Better weather, visual effects and optimized baked lighting.

**Exit criteria:** 2–3 hours of curated gameplay and successful save migration tests.

## Release 1.0 — Public indie release (schedule depends on team, funding and testing)

- Content completion, UX/accessibility review, browser/device QA, privacy and license audit.
- Automated gameplay and save migration tests, crash reporting only if consent-based and documented.
- Performance and memory profiling; localization and controller support.

**Exit criteria:** Public release checklist passed on supported browsers and devices. No promise of photorealism, MMO scale, or fixed ship date is implied.

## Technical risk register

| Risk | Impact | Mitigation |
| --- | --- | --- |
| WebGL 2 support varies | Browser compatibility | Compatibility renderer; published browser matrix; real-device QA |
| Mobile memory / GPU budget | Slow frame rate or crashes | Mesh LOD, instancing, texture compression, draw-call and memory profiling |
| Procedural geometry looks simplistic | Visual quality gap | Treat first version as a vertical slice; replace with optimized original authored assets |
| Save data changes | Lost progress | Versioned saves, migration tests, backup on schema change |
| NPC and traffic AI complexity | CPU cost and bugs | Fixed update budgets, simulation LOD, deterministic tests |
| Art/audio rights | Distribution risk | Keep source files, licenses and attribution manifest for every new asset |
| Godot engine/export changes | CI breakage | Pin 4.4.1 and update only after green import/export tests |
