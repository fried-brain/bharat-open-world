# BHARAT: Open World Implementation Plan

> **For agentic workers:** Use the host's available task-by-task implementation workflow. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a GitHub-ready Godot 4.4.1 browser-playable Indian village exploration vertical slice, with a documented path toward an ambitious open-world game.

**Architecture:** A scene root orchestrates a deterministic procedural village, a third-person `CharacterBody3D`, a pure quest state machine, and a Godot Control HUD. Gameplay state persists to versioned local JSON, while GitHub Actions imports, tests and exports a WebGL 2 build.

**Tech Stack:** Godot 4.4.1, GDScript, GL Compatibility renderer, Python 3 static checks, GitHub Actions, GitHub Pages, original generated WAV audio and icon.

## Global Constraints

- Target platform: web browser; engine: Godot; scope: ambitious longer-term vision.
- First delivery must be a playable, manageable vertical slice; no false claim of finished large-world content.
- Original or freely licensed assets only; MIT license for repository-owned content.
- Code, assets, tests, documentation, Web export preset and GitHub CI/deployment must be included.
- Browser game must be testable without proprietary services or paid software.
- No Godot executable was available in the authoring container. Engine and browser test status must be reported as unverified until CI runs.

---

### Task 1: Bootable 3D village and player

**Files:**
- Create: `project.godot`, `scenes/main.tscn`, `scripts/world_builder.gd`, `scripts/player_controller.gd`
- Test: `tests/smoke_test.gd`, `tests/static_check.py`

**Interfaces:**
- Consumes: Godot 4.4.1 scene loader and InputMap actions.
- Produces: `VillageWorld.new()`, `VillageWorld.nearest_person(at: Vector3, max_distance: float = 3.7) -> Dictionary`, `VillagePlayer.new()`.

- [x] **Step 1: Add focused failing test** — Verify the scene and scripts exist; Godot smoke test expects village and player nodes.
- [ ] **Step 2: Verify relevant failure** — On a Godot-capable runner, run `godot --headless --path . --script res://tests/smoke_test.gd` before implementation; missing classes should fail. Not runnable in the authoring container.
- [x] **Step 3: Implement minimum behavior** — Generate terrain, roads, houses, temple, pond, NPC models, collision and camera-relative movement; clamp world position to ±65 units.
- [ ] **Step 4: Verify focused pass** — Run Godot smoke test and assert six NPCs and four landmarks; pending Godot runtime.
- [ ] **Step 5: Run integration check** — `godot --headless --path . --import`; expected no parse errors; pending Godot runtime.
- [ ] **Step 6: Commit** — `git add project.godot scenes scripts/world_builder.gd scripts/player_controller.gd tests && git commit -m "feat: create playable village foundation"` on the user's repository.

### Task 2: Missions, weather, map and save

**Files:**
- Create: `scripts/quest_manager.gd`, `scripts/minimap.gd`, `scripts/main.gd`
- Test: `tests/smoke_test.gd`

**Interfaces:**
- Consumes: `VillageWorld.nearest_person()`, `VillageWorld.points_of_interest`, `VillagePlayer.global_position`.
- Produces: `VillageQuests.interact(person_id: String) -> String`, `VillageQuests.objective() -> Dictionary`, `VillageQuests.discover(id: String) -> bool`, `VillageQuests.serialize() -> Dictionary`, `VillageQuests.load_progress(data: Dictionary) -> void`, `user://bharat_save.json`.

- [x] **Step 1: Add focused failing test** — Assert wrong NPC does not advance quest, correct four-NPC order does, discovery is idempotent, save state round-trips, and out-of-range quest step clamps.
- [ ] **Step 2: Verify relevant failure** — Godot smoke test before adding `VillageQuests` should report missing class; pending engine runtime.
- [x] **Step 3: Implement minimum behavior** — HUD and minimap, proximity dialogue, four mission stages, four landmark discoveries, time/day-night lighting, toggled monsoon rain, versioned save and guarded load. Malformed JSON returns false; no target remains after quest completion.
- [ ] **Step 4: Verify focused pass** — Run `godot --headless --path . --script res://tests/smoke_test.gd`; expected `BHARAT_SMOKE_TEST_PASSED`; pending runtime.
- [ ] **Step 5: Run integration check** — Manual web test: complete four missions, reload, verify mission remains completed; pending browser build.
- [ ] **Step 6: Commit** — `git add scripts/main.gd scripts/quest_manager.gd scripts/minimap.gd tests && git commit -m "feat: add village missions and persistence"` on user's repository.

### Task 3: Audio, Web export and continuous integration

**Files:**
- Create: `assets/audio/village_ambience.wav`, `assets/audio/interaction.wav`, `assets/icon.png`, `export_presets.cfg`, `.github/workflows/ci.yml`, `.github/workflows/pages.yml`
- Test: `tests/static_check.py`, `tests/smoke_test.gd`

**Interfaces:**
- Consumes: Godot project and pinned Godot 4.4.1 export templates.
- Produces: `build/web/index.html` and companion exported files; CI artifact `bharat-web-build`; GitHub Pages URL after user configures repository Pages.

- [x] **Step 1: Add focused failing test** — Check WAV files are readable and required export preset and workflow files exist.
- [x] **Step 2: Verify relevant failure** — Static check initially requires missing audio, documentation and export files.
- [x] **Step 3: Implement minimum behavior** — Create original synthesized audio and icon, Web preset and GitHub Actions workflows; CI runs import, smoke tests and Web export.
- [ ] **Step 4: Verify focused pass** — `python tests/static_check.py` expected `STATIC_CHECKS_PASSED`; Godot runtime remains pending.
- [ ] **Step 5: Run integration check** — On GitHub Actions, exported `index.html` and `index.pck` must be nonempty and Pages deployment successful.
- [ ] **Step 6: Commit** — `git add assets export_presets.cfg .github tests && git commit -m "build: add original assets and web CI"` on user's repository.

### Task 4: Repository handoff and release readiness

**Files:**
- Create: `README.md`, `LICENSE`, `.gitignore`, `docs/ARCHITECTURE.md`, `docs/ROADMAP.md`, `docs/plans/2026-11-13-bharat-open-world.md`
- Test: `tests/static_check.py`

**Interfaces:**
- Consumes: all game and build files.
- Produces: documented GitHub-ready source tree with reproducible setup, testing, Web export and deployment steps.

- [x] **Step 1: Add focused failing test** — Assert all key source, license and documentation files exist.
- [x] **Step 2: Verify relevant failure** — Missing required docs would fail `tests/static_check.py`.
- [x] **Step 3: Implement minimum behavior** — Document features, limitations, architecture, roadmap, GitHub Pages setup, controls, QA and original-asset licensing.
- [ ] **Step 4: Verify focused pass** — Run `python tests/static_check.py`; expected `STATIC_CHECKS_PASSED`.
- [ ] **Step 5: Run integration check** — Unzip artifact, confirm `project.godot`, run CI in user's GitHub repository, verify hosted game on real browser/device.
- [ ] **Step 6: Commit** — `git add README.md LICENSE .gitignore docs && git commit -m "docs: publish architecture and development roadmap"` on user's repository.

## Unresolved product decisions

- **Art direction:** Current delivery uses original low-poly stylized placeholder meshes; photorealistic asset pipeline, licensing and performance budgets require future approval.
- **Target devices:** Minimum supported Android/browser GPU and performance baseline require real-device testing.
- **Game language:** English UI is provided; Hindi localization and voice acting remain a future scope choice.
- **Driving and world size:** Vehicle types, map extent and content priorities require milestone planning before implementation.
- **Publication:** User must create or connect a GitHub repository and enable GitHub Actions Pages; no repository has been published by the authoring environment.
