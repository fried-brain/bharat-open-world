# Technical Architecture — BHARAT: Open World

## Runtime

- **Engine:** Godot 4.4.1 (standard, GDScript), WebGL 2 via Compatibility renderer.
- **Scene entry:** `scenes/main.tscn` with `scripts/main.gd` on a `Node3D` root.
- **World:** `VillageWorld` builds deterministic environment, houses, paths, NPC visual meshes, landmark registry and lighting at startup. It exposes `people`, `points_of_interest`, `nearest_person(at, max_distance)`, `set_clock(hour)` and `animate_people(seconds)`.
- **Player:** `VillagePlayer` extends `CharacterBody3D`, creates capsule collision and third-person camera; movement is driven by `InputMap` actions. The world ground and buildings are on collision layer 1, player is layer 2 with mask 1.
- **Quests:** `VillageQuests` is a `RefCounted` pure state machine. `interact(person_id)` advances only when the expected NPC is contacted. `discover(id)` is idempotent. `serialize()` and `load_progress(data)` exchange dictionaries.
- **HUD:** `scripts/main.gd` dynamically builds Godot Control nodes, on-screen controls and menu. `VillageMinimap` draws roads, player, landmarks and current target using 2D primitives.
- **Weather/time:** Clock advances at 0.014 in-game hours per real second. Rain toggles a bounded `CPUParticles3D` emitter. Lighting changes at day/night thresholds.
- **Persistence:** `user://bharat_save.json` is a versioned JSON save with `save_version`, `quest_step`, `discovered`, `clock_hours`, `weather`, `position`. On load, quest steps and coordinates are clamped; malformed JSON returns false. `user://` is local to the platform/browser profile and is not a cloud account.
- **Audio:** Two original PCM mono WAV assets; ambience loops and interactions play a short chime.

## Interaction contracts

| Producer | Consumer | Contract |
| --- | --- | --- |
| `VillageWorld.nearest_person(Vector3)` | `main._interact()` | Empty dictionary if none within 3.7 units; otherwise `id`, `name`, `node` |
| `VillageQuests.objective()` | `main._update_hud()` | Dictionary with `target`, `title`, `description`; empty target after completion |
| `VillageQuests.serialize()` | `main._save_game()` | Dictionary containing `quest_step`, `discovered` |
| `VillageWorld.points_of_interest` | `VillageMinimap`, discovery logic | Each dictionary has `id`, `name`, `position` |
| `InputMap` actions | `VillagePlayer`, `main` | `move_*`, `sprint`, `jump`, `camera_*`, `interact`, `menu`, `weather` |

## Boundaries and future evolution

World creation is currently synchronous because the village is intentionally small. For a 2 km² world, move environment content into authored scenes and asynchronously loaded chunks. NPC AI will move to behavior trees / navigation agents, with server-authoritative state only if multiplayer is introduced. Driving will be a separate vehicle subsystem, not mixed into the player controller. Save version migration must be implemented before changing the JSON schema. Texture and audio budgets must be tracked before introducing high-resolution art.

## Security and privacy

The project has no telemetry, remote APIs, login, ads or analytics. Saves are local and contain only gameplay state. Avoid accepting executable content from save data. GitHub Actions use the minimal Pages permissions needed to deploy.
