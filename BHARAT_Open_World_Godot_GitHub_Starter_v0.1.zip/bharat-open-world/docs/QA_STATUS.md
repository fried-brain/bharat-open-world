# QA status — initial source delivery

| Verification | Result | Evidence |
| --- | --- | --- |
| Required repository files | PASS | `python tests/static_check.py` |
| Quest ordering and required source identifiers (static) | PASS | `python tests/static_check.py` |
| WAV file readability | PASS | `python tests/static_check.py` |
| Godot GDScript parser/import | NOT RUN | Godot executable unavailable in authoring environment |
| Godot integration smoke tests | NOT RUN | Requires Godot 4.4.1; run in CI |
| Web export | NOT RUN | Requires Godot 4.4.1 + Web templates; run in CI |
| Browser interaction, touch and FPS | NOT RUN | Requires exported build and browser/device QA |
| GitHub Pages publication | NOT RUN | User must upload repo and enable Pages |

## Acceptance sequence

1. Run `python tests/static_check.py` (expect `STATIC_CHECKS_PASSED`).
2. Run `godot --headless --path . --import` (expect exit 0 and no parse errors).
3. Run `godot --headless --path . --script res://tests/smoke_test.gd` (expect `BHARAT_SMOKE_TEST_PASSED`).
4. Run `godot --headless --path . --export-release "Web" build/web/index.html` (expect HTML, JS, WASM, PCK files).
5. Serve `build/web` over HTTP, finish all four quests, reload save, visit four landmarks, test rain/day-night and keyboard/touch.
6. Measure FPS, memory and load time on a desktop Chrome/Firefox browser and target Android Chrome device.

Any failed check is a release blocker. Do not label this pre-alpha as runtime-verified until the above tests are completed.
