extends SceneTree
## Run with: godot --headless --path . --script res://tests/smoke_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var q := VillageQuests.new()
    _check(q.objective()["target"] == "chai", "Quest begins at chai stall")
    _check(q.interact("doctor").length() > 0 and q.step == 0, "Wrong NPC does not advance")
    for npc in ["chai", "post", "doctor", "elder"]:
        q.interact(npc)
    _check(q.step == 4, "Four quests can be completed")
    _check(q.objective()["target"] == "", "Completed quest has no target")
    _check(q.discover("pond"), "First discovery counts")
    _check(not q.discover("pond"), "Duplicate discovery ignored")
    var saved := q.serialize()
    var restored := VillageQuests.new()
    restored.load_progress(saved)
    _check(restored.step == 4 and restored.completed_landmarks.size() == 1, "Progress round-trip")
    restored.load_progress({"quest_step": 1000, "discovered": ["temple", "temple"]})
    _check(restored.step == 4 and restored.completed_landmarks.size() == 1, "Corrupt progression clamped")

    var scene: PackedScene = load("res://scenes/main.tscn")
    _check(scene != null, "Main scene loads")
    if scene != null:
        var game := scene.instantiate()
        root.add_child(game)
        _check(game.get_node_or_null("Sundarpur") != null, "Village generated")
        _check(game.get_node_or_null("Explorer") != null, "Player generated")
        if game.world != null:
            _check(game.world.people.size() == 6, "Six NPCs generated")
            _check(game.world.points_of_interest.size() == 4, "Four landmarks generated")
        game.queue_free()
    print("BHARAT_SMOKE_TEST_PASSED")
    quit(0)

func _check(condition: bool, description: String) -> void:
    if not condition:
        push_error("FAILED: " + description)
        quit(1)
        assert(condition, description)
