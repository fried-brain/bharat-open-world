"""Offline checks for source layout and Godot project invariants (not engine runtime tests)."""
from pathlib import Path
import re
import wave

ROOT = Path(__file__).resolve().parents[1]
required = [
    "project.godot", "export_presets.cfg", "scenes/main.tscn",
    "scripts/main.gd", "scripts/world_builder.gd", "scripts/player_controller.gd",
    "scripts/quest_manager.gd", "scripts/minimap.gd", "tests/smoke_test.gd",
    "README.md", "LICENSE", "docs/ARCHITECTURE.md", "docs/ROADMAP.md", "docs/QA_STATUS.md",
    "assets/audio/village_ambience.wav", "assets/audio/interaction.wav",
]
for relative in required:
    path = ROOT / relative
    assert path.is_file() and path.stat().st_size > 0, f"Missing or empty: {relative}"

project = (ROOT / "project.godot").read_text()
assert 'run/main_scene="res://scenes/main.tscn"' in project
assert 'gl_compatibility' in project
assert 'platform="Web"' in (ROOT / "export_presets.cfg").read_text()

quest = (ROOT / "scripts/quest_manager.gd").read_text()
assert re.findall(r'"target": "(chai|post|doctor|elder)"', quest) == ["chai", "post", "doctor", "elder"]
assert "clampi" in quest and "completed_landmarks" in quest

world = (ROOT / "scripts/world_builder.gd").read_text()
for landmark in ("Shanti Mandir", "Lotus Pond", "Village School", "Village Hall"):
    assert landmark in world
for npc in ("chai", "post", "doctor", "elder", "walker1", "walker2"):
    assert f'"{npc}"' in world

main = (ROOT / "scripts/main.gd").read_text()
for token in ("_save_game", "_load_game", "_toggle_weather", "_setup_touch_controls", "_interact"):
    assert token in main

for wav in ("village_ambience.wav", "interaction.wav"):
    with wave.open(str(ROOT / "assets/audio" / wav), "rb") as stream:
        assert stream.getnframes() > 2000 and stream.getnchannels() == 1

print("STATIC_CHECKS_PASSED: 15 required files, quest flow, landmarks, NPCs, audio, Web export")
